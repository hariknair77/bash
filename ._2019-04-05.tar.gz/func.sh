#!/usr/bin/bash
function user_details {
	echo "Username: $(whoami)"
	echo "Home directory: $HOME"
}

user_details