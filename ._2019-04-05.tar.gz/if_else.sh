#!/usr/bin/bash
num_1=100
num_2=200

if [ $num_1 -lt $num_2 ];then
	echo "$num_1 is less than $num_2"
else
	echo "$num_1 is greater than $num_2"
fi	
