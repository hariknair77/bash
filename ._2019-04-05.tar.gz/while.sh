#!/usr/bin/bash
i=0
while [ $i -lt 10 ];do
	let i+=1
	echo $i
done
