#!/usr/bin/bash
echo $1 $2 $4
echo $#
echo $*
